#define VMOD_ABI_Version "Varnish 3.0.5 1a89b1f"
