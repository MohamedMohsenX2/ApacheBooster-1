/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit and run generate.py instead
 */
#define	CNUM 128
#define	CSRC 129
#define	CSTR 130
#define	EOI 131
#define	ID 132
#define	T_CAND 133
#define	T_COR 134
#define	T_DEC 135
#define	T_DECR 136
#define	T_DIV 137
#define	T_ELSE 138
#define	T_ELSEIF 139
#define	T_ELSIF 140
#define	T_EQ 141
#define	T_GEQ 142
#define	T_IF 143
#define	T_INC 144
#define	T_INCLUDE 145
#define	T_INCR 146
#define	T_LEQ 147
#define	T_MUL 148
#define	T_NEQ 149
#define	T_NOMATCH 150
#define	T_SHL 151
#define	T_SHR 152
