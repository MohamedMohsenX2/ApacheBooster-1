Prerequisites
=============


In order for you to install Varnish you must have the following:

  * A fairly modern and 64 bit version of either
    - Linux
    - FreeBSD
    - Solaris
  * root access to said system


Varnish can be installed on other UNIX systems as well, but it is not
tested particularly well on these plattforms. Varnish is, from time to
time, said to work on: 

  * 32 bit versions of the before-mentioned systems.
  * OS X
  * NetBSD
  * OpenBSD

